# an offline map demo use **Leaflet**

*how to use:* [在 Web 页面中使用离线地图](https://www.cnblogs.com/victorbu/p/10303965.html)

*reference:*

- [java离线地图web GIS制作](http://www.cnblogs.com/kanyun/p/8571711.html)

- [chenwuwen/OffineMap](https://github.com/chenwuwen/OffineMap)

