# spring boot cache + redis

*Blog:* [Spring Boot 自带缓存及结合 Redis 使用](https://www.cnblogs.com/victorbu/p/10876589.html)

