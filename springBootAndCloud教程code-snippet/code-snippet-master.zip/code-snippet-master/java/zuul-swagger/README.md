# zuul + swagger 2

*Blog:* [使用 Zuul 聚合多个微服务的 Swagger 文档](https://www.cnblogs.com/victorbu/p/11128256.html)

