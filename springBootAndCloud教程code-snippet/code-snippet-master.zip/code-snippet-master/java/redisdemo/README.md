# spring boot + redis demo

*Blog:* [Spring Boot + Redis 初体验](https://www.cnblogs.com/victorbu/p/10869528.html)

