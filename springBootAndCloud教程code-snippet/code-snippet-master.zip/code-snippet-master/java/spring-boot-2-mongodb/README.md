# spring boot 2 + mongodb

*Blog:* [Spring Boot + MongoDB 使用示例](https://www.cnblogs.com/victorbu/p/11266806.html)

*Blog:* [基于 MongoDB 动态字段设计的探索](https://www.cnblogs.com/victorbu/p/11281608.html)

*Blog:* [基于 MongoDB 动态字段设计的探索 (二) 聚合操作](https://www.cnblogs.com/victorbu/p/11293743.html)
