# spring boot 2 + elasticsearch

*Blog:* [Spring Boot + Elasticsearch 使用示例](https://www.cnblogs.com/victorbu/p/11238372.html)

