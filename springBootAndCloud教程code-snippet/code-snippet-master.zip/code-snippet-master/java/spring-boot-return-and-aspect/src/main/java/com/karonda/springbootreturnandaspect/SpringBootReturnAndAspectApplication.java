package com.karonda.springbootreturnandaspect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReturnAndAspectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReturnAndAspectApplication.class, args);
	}

}
