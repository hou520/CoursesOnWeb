package com.karonda.springbootreturnandaspect.core;

public interface CommonResult {

    Integer getCode();

    String getMsg();

    void setMsg(String msg);

}
