package com.karonda.dubboservice;

public interface GreetingService {
    String greeting();
}
