package com.karonda.service2.service;

import com.karonda.model.Order;

public interface BusinessService {
    void purchase(Order order) throws Exception;
}
