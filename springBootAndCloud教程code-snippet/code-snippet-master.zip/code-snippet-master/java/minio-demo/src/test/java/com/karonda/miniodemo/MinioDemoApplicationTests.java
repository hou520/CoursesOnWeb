package com.karonda.miniodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinioDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
