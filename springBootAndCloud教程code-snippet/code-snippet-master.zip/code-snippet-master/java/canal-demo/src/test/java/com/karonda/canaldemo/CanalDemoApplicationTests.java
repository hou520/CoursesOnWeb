package com.karonda.canaldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanalDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
