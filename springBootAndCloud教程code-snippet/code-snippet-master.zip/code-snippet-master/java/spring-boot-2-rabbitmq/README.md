# spring boot 2 + rabbitmq

*Blog:* [Spring Boot + RabbitMQ 使用示例](https://www.cnblogs.com/victorbu/p/11181397.html)

