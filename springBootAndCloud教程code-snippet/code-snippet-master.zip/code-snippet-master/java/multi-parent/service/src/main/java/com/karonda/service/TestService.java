package com.karonda.service;

public interface TestService {
    void Test();
}
