package com.karonda.dao;

public interface TestDao {
    void Test();
}
