# idea multi module project

*Blog:* [使用 IDEA 创建多模块项目](https://www.cnblogs.com/victorbu/p/10895676.html)

