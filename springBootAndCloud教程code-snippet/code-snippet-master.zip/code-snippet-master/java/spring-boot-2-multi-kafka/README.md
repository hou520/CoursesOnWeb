# spring boot + kafka (multi)

*Blog:* [Spring Boot 集成多个 Kafka](https://www.cnblogs.com/victorbu/p/12068393.html)

