package com.karonda.springboot2multikafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot2MultiKafkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
