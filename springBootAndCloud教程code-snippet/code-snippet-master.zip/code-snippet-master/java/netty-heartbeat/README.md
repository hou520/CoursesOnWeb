# netty heartbeat

*Blog:* [Netty 心跳处理](https://www.cnblogs.com/victorbu/p/12006047.html)

