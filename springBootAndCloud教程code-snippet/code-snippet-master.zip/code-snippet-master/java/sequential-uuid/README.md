# sequential uuid

*Blog:* [Java 生成有序 UUID](https://www.cnblogs.com/victorbu/p/11098647.html)

