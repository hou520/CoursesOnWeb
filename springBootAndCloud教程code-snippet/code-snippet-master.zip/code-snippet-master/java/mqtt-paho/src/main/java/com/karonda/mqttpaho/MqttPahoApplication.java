package com.karonda.mqttpaho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MqttPahoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MqttPahoApplication.class, args);
    }

}
