# spring boot 2 + sharding-jdbc

*Blog:* [Spring Boot + Sharding-JDBC 读写分离](https://www.cnblogs.com/victorbu/p/11250755.html)

