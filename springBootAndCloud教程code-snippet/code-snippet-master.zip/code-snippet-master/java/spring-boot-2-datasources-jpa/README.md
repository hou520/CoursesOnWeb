# spring boot 2 multi datasources use jpa

*Blog:* [Spring Boot 2.x 多数据源配置之 JPA 篇](https://www.cnblogs.com/victorbu/p/10952373.html)

