package com.karonda.mysqldatarestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlDataRestoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(MysqlDataRestoreApplication.class, args);
    }

}
