package com.karonda.mysqldatarestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlDataRestoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
