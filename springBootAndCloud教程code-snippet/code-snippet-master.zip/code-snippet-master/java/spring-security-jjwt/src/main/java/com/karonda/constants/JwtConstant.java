package com.karonda.constants;

public class JwtConstant {
    public static final String AIM_KEY = "aim";
    public static final String AIM_ACCESS = "access";
    public static final String AIM_REFRESH = "refresh";

    public static final String USER_INFO_KEY = "user_info";
}
