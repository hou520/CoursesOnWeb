# hls (.m3u8) downloader

*Blog:* [Java 下载 HLS (m3u8) 视频](https://www.cnblogs.com/victorbu/p/10347663.html)

*reference:*

- [M3U8在线视频文件下载合成MP4视频](https://my.oschina.net/haitaohu/blog/1941179)

