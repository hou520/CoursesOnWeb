# spring boot 2 + swagger 2

*Blog:* [Spring Boot 2 集成 Swagger](https://www.cnblogs.com/victorbu/p/11094359.html)

