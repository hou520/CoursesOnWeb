package com.karonda.nettywebsocketserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NettyWebsocketServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(NettyWebsocketServerApplication.class, args);
    }

}
