package com.karonda.nettywebsocketserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NettyWebsocketServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
