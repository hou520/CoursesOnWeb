# netty  + websocket

*Blog:* [Netty 搭建 WebSocket 服务端](https://www.cnblogs.com/victorbu/p/11980976.html)

