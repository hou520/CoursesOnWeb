# twitter snowflake

*Blog:* [雪花算法 Java 版](https://www.cnblogs.com/victorbu/p/11101850.html)

