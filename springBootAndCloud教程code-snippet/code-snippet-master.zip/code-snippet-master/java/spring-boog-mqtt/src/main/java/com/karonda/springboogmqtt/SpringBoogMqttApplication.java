package com.karonda.springboogmqtt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoogMqttApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBoogMqttApplication.class, args);
    }

}
