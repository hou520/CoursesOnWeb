package com.karonda.springboogmqtt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoogMqttApplicationTests {

    @Test
    void contextLoads() {
    }

}
