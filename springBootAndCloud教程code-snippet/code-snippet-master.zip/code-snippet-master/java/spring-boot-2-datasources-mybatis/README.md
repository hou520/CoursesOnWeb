# spring boot 2 multi datasources use mybatis

*Blog:* [Spring Boot 2.x 多数据源配置之 MyBatis 篇](https://www.cnblogs.com/victorbu/p/10983184.html)

