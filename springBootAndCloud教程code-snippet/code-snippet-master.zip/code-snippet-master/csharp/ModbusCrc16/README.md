# Modbus CRC 16

*blog:* [Modbus CRC 16 (C#)](https://www.cnblogs.com/victorbu/p/10393061.html)

