# HJ212 CRC 16

*blog:* [HJ212 CRC 16 (C#)](https://www.cnblogs.com/victorbu/p/10393148.html)

