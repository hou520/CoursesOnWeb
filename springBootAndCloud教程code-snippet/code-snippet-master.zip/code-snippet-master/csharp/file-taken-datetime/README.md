# file-taken-datetime

*reference:*

- [how-do-i-find-the-date-a-video-avi-mp4-was-actually-recorded](https://stackoverflow.com/questions/3104641/how-do-i-find-the-date-a-video-avi-mp4-was-actually-recorded)

